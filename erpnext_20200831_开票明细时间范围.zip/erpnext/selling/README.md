Selling management module. Includes forms for capturing / managing the sales process:

- Customer
- Campaign
- Quotation
- Sales Order

Moved to CRM Module:

- Lead
- Opportunity
