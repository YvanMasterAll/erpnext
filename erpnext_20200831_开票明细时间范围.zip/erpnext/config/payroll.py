from __future__ import unicode_literals
from frappe import _

# Change: 添加模块配置，数据为空，目的是在用户配置的允许模块中体现
def get_data():
	return []