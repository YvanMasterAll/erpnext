from __future__ import unicode_literals

source_link = "https://github.com/erpnext/foundation"
