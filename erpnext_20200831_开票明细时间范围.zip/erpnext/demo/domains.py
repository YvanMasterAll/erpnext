from __future__ import unicode_literals

data = {
	'Manufacturing': {
		'company_name': 'Wind Power LLC'
	},
	'Retail': {
		'company_name': 'Mobile Next',
	},
	'Distribution': {
		'company_name': 'Soltice Hardware',
	},
	'Services': {
		'company_name': 'Acme Consulting'
	},
	'Education': {
		'company_name': 'Whitmore College'
	},
	'Healthcare': {
		'company_name': 'ABC Hospital Ltd.'
	},
	'Agriculture': {
		'company_name': 'Schrute Farms'
  },
	'Non Profit': {
		'company_name': 'Erpnext Foundation'
	}
}