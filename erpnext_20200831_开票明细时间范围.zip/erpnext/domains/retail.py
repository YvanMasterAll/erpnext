from __future__ import unicode_literals

data = {
	'desktop_icons': [
		'POS',
		'Item',
		'Customer',
		'Sales Invoice',
		'Purchase Order',
		'Accounts',
		'Task',
		'ToDo'
	],
	'set_value': [
		['Stock Settings', None, 'show_barcode_field', 1]
	],
	'default_portal_role': 'Customer'
}
