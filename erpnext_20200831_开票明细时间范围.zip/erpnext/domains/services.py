from __future__ import unicode_literals

data = {
	'desktop_icons': [
		'Project',
		'Timesheet',
		'Customer',
		'Sales Order',
		'Sales Invoice',
		'CRM',
		'Task',
		'Expense Claim',
		'Employee',
		'HR',
		'ToDo'
	],
	'set_value': [
		['Stock Settings', None, 'show_barcode_field', 0]
	],
	'default_portal_role': 'Customer'
}