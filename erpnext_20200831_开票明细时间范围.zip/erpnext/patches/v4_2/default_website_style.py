from __future__ import unicode_literals
import frappe

def execute():
	return
	# frappe.reload_doc('website', 'doctype', 'style_settings')
	# style_settings = frappe.get_doc("Style Settings", "Style Settings")
	# if not style_settings.apply_style:
	# 	style_settings.update(default_properties)
	# 	style_settings.apply_style = 1
	# 	style_settings.save()
