Manage buying (purchasing).

Transactions include:

- Material Request
- Supplier Quotation
- Purchase Order
- Quality Inspection